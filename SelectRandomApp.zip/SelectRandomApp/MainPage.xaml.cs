﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace SelectRandomApp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public object choices { get; set; }

        public MainPage()
        {
            this.InitializeComponent();
        }

        private void TextBlock_SelectionChanged(object sender, RoutedEventArgs e)
        {

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        public void RandomChoices()
        {
            string a = Convert.ToString(First_Input.Text);
            string b = Convert.ToString(Second_Input.Text);
            string c = Convert.ToString(Third_Input.Text);
            string d = Convert.ToString(Fourth_Input.Text);
            string e = Convert.ToString(Fifth_Input.Text);
            List<String> choices = new List<String>();
            choices.AddRange(new String[]
                { a, b, c, d, e});
            Random random = new Random();
            Result.Text = choices[random.Next(0, choices.Count)];
        }

        public void Randomize(object sender, RoutedEventArgs e)
        {
            RandomChoices();
        }
    }
}
